package com.example.teamo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.teamo.databinding.ActivityDetailDataBinding
import com.example.teamo.databinding.ActivityMainBinding
import com.example.teamo.modeldata.ModelDetailData
import com.example.teamo.modeldata.SkripsiDetailData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailData : AppCompatActivity() {
    var b : Bundle? = null
    private lateinit var binding : ActivityDetailDataBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        b = intent.extras
        val id = b?.getString("id")
        val category = "2"

        RData.instances.getDetailData(id,category).enqueue(object : Callback<SkripsiDetailData>{
            override fun onResponse(
                call: Call<SkripsiDetailData>,
                response: Response<SkripsiDetailData>
            ) {
                binding.judulLaporan.text = response.body()?.judul
                binding.penulisLaporan.text = response.body()?.penulis
                binding.tahunLaporan.text = response.body()?.tahun
                binding.pembimbingLaporan.text = response.body()?.pembimbing
                binding.abstrakLaporan.text = response.body()?.abstrak
            }

            override fun onFailure(call: Call<SkripsiDetailData>, t: Throwable) {

            }

        })

    }
}
package com.example.teamo.modeldata

import com.google.gson.annotations.SerializedName

data class Data (
    @SerializedName("success") val success:String,
    @SerializedName("data") val data:List<SkripsiData>,
    @SerializedName("id") val idData:String,
)
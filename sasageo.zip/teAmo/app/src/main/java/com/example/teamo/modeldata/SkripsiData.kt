package com.example.teamo.modeldata




data class SkripsiData (
    val judul:String,
    val tahun:String,
    val id:String,
    val penulis:String

)
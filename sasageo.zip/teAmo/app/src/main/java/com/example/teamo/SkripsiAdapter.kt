package com.example.teamo

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.teamo.databinding.ListDatamahasiswaBinding
import com.example.teamo.modeldata.SkripsiData

class SkripsiAdapter(
    private val listSkripsi:ArrayList<SkripsiData>,
    private val context: Context

):RecyclerView.Adapter<SkripsiAdapter.SkripsiViewHolder>(){

    inner class SkripsiViewHolder(itemView:ListDatamahasiswaBinding):RecyclerView.ViewHolder(itemView.root){
        private val binding = itemView
        fun bind(skripsiData: SkripsiData){
            with(binding){
                tvJudul.text = skripsiData.judul
                tvNama.text = skripsiData.penulis
                tvTahun.text = skripsiData.tahun

                cvIdData.setOnClickListener {
                    var i = Intent(context,DetailData::class.java).apply {
                        putExtra("id",skripsiData.id)
                    }
                    context.startActivity(i)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkripsiViewHolder {
        return SkripsiViewHolder(ListDatamahasiswaBinding.inflate(LayoutInflater.from(parent.context),
        parent,false))
    }

    override fun onBindViewHolder(holder: SkripsiViewHolder, position: Int) {
        holder.bind(listSkripsi[position])
    }

    override fun getItemCount(): Int = listSkripsi.size

}

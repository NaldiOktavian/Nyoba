package com.example.teamo

import com.example.teamo.modeldata.Data
import com.example.teamo.modeldata.ModelDetailData
import com.example.teamo.modeldata.SkripsiDetailData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface Api {

    @GET("search")
    fun getData(
        @Query("nama") nama:String?,
        @Query("category") category: String
    ):Call<Data>

    @GET("getdetaildata")
    fun getDetailData(
        @Query("id") id:String?,
        @Query("category") category: String
    ):Call<SkripsiDetailData>
}
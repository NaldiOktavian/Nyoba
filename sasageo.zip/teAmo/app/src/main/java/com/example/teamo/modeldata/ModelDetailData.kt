package com.example.teamo.modeldata

import com.google.gson.annotations.SerializedName

data class ModelDetailData(
    @SerializedName("success") val success:String,
    @SerializedName("data") val data:List<SkripsiDetailData>

)

data class SkripsiDetailData(
    val judul:String,
    val tahun:String,
    val id:String,
    val penulis:String,
    val pembimbing:String,
    val abstrak:String,
    val public:String,
    val private:String,
)
